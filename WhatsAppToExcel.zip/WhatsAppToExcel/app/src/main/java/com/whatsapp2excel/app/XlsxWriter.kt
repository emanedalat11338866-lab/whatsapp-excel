package com.whatsapp2excel.app

import java.io.OutputStream
import java.io.OutputStreamWriter
import java.io.Writer
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * نویسندهٔ ساده و بدون وابستگی برای فایل .xlsx
 * ویژگی‌ها: راست‌به‌چپ، ردیف عنوان رنگی، فریز ردیف اول، فیلتر، عرض ستون و شکستن خط.
 */
object XlsxWriter {

    private const val NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val MAX_CELL = 32000

    fun write(
        out: OutputStream,
        sheetName: String,
        headers: List<String>,
        rows: Sequence<List<Any>>,
        rowCount: Int,
        widths: List<Double>
    ) {
        val zip = ZipOutputStream(out.buffered())
        val w = OutputStreamWriter(zip, Charsets.UTF_8)

        fun entry(name: String, body: (Writer) -> Unit) {
            zip.putNextEntry(ZipEntry(name))
            body(w)
            w.flush()
            zip.closeEntry()
        }

        entry("[Content_Types].xml") {
            it.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""
            )
        }

        entry("_rels/.rels") {
            it.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""
            )
        }

        entry("xl/workbook.xml") {
            it.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="$NS" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<bookViews><workbookView rightToLeft="1"/></bookViews>
<sheets><sheet name="${esc(sheetName)}" sheetId="1" r:id="rId1"/></sheets>
</workbook>"""
            )
        }

        entry("xl/_rels/workbook.xml.rels") {
            it.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""
            )
        }

        entry("xl/styles.xml") {
            it.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="$NS">
<fonts count="2">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
</fonts>
<fills count="3">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF17365D"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="2">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""
            )
        }

        entry("xl/worksheets/sheet1.xml") { sw ->
            sw.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            sw.write("""<worksheet xmlns="$NS">""")
            sw.write(
                """<sheetViews><sheetView rightToLeft="1" workbookViewId="0">""" +
                    """<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>""" +
                    """</sheetView></sheetViews>"""
            )
            sw.write("""<sheetFormatPr defaultRowHeight="15"/>""")

            sw.write("<cols>")
            widths.forEachIndexed { i, wd ->
                sw.write("""<col min="${i + 1}" max="${i + 1}" width="$wd" customWidth="1"/>""")
            }
            sw.write("</cols>")

            sw.write("<sheetData>")

            // ردیف عنوان
            sw.write("""<row r="1" ht="25" customHeight="1">""")
            headers.forEachIndexed { c, h ->
                sw.write("""<c r="${colName(c)}1" s="1" t="inlineStr"><is><t>${esc(h)}</t></is></c>""")
            }
            sw.write("</row>")

            // ردیف‌های داده
            var r = 2
            for (row in rows) {
                sw.write("""<row r="$r">""")
                row.forEachIndexed { c, v ->
                    val ref = "${colName(c)}$r"
                    when (v) {
                        is Int, is Long -> sw.write("""<c r="$ref" s="0"><v>$v</v></c>""")
                        else -> {
                            val s = v.toString().let { if (it.length > MAX_CELL) it.substring(0, MAX_CELL) else it }
                            if (s.isEmpty()) {
                                sw.write("""<c r="$ref" s="0"/>""")
                            } else {
                                sw.write(
                                    """<c r="$ref" s="0" t="inlineStr"><is><t xml:space="preserve">${esc(s)}</t></is></c>"""
                                )
                            }
                        }
                    }
                }
                sw.write("</row>")
                r++
            }

            sw.write("</sheetData>")
            val last = rowCount + 1
            sw.write("""<autoFilter ref="A1:${colName(headers.size - 1)}$last"/>""")
            sw.write("</worksheet>")
        }

        zip.finish()
        zip.flush()
    }

    private fun colName(index: Int): String {
        var n = index
        val sb = StringBuilder()
        do {
            sb.insert(0, ('A' + n % 26))
            n = n / 26 - 1
        } while (n >= 0)
        return sb.toString()
    }

    /** escape کردن XML و حذف نویسه‌های کنترلی غیرمجاز */
    private fun esc(s: String): String {
        val sb = StringBuilder(s.length + 16)
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch == '\n' || ch == '\t' || ch == '\r' -> sb.append(ch)
                ch.code < 0x20 -> {}
                ch.code == 0xFFFE || ch.code == 0xFFFF -> {}
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}
