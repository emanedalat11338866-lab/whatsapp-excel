package com.whatsapp2excel.app

data class ChatMessage(
    val date: String,
    val time: String,
    val sender: String,
    var text: String,
    val amount: String,
    val source: String
)

object WhatsAppParser {

    // فرمت اندروید:  12/03/2024, 10:15 - نام: متن
    private val androidPattern = Regex(
        """(?U)^[‎‏]*(\d{1,4}[/-]\d{1,2}[/-]\d{1,4})[,\s]+(\d{1,2}:\d{2}(?::\d{2})?(?:\s?[APap][Mm])?)\s+-\s+(.+?):\s(.*)$"""
    )

    // فرمت آیفون:  [12/03/2024, 10:15:30] نام: متن
    private val iosPattern = Regex(
        """(?U)^[‎‏]*\[(\d{1,4}[/-]\d{1,2}[/-]\d{1,4})[,\s]+(\d{1,2}:\d{2}(?::\d{2})?(?:\s?[APap][Mm])?)\]\s+(.+?):\s(.*)$"""
    )

    private val amountPattern = Regex("""(?U)(?<!\w)[+-]?\d[\d,٫٬.]*""")

    fun extractAmount(text: String): String =
        amountPattern.findAll(text).joinToString(" | ") { it.value }

    /** رمزگشایی فایل: UTF-16 (با BOM) یا UTF-8 */
    fun decode(bytes: ByteArray): String {
        if (bytes.size >= 2) {
            val b0 = bytes[0].toInt() and 0xFF
            val b1 = bytes[1].toInt() and 0xFF
            if (b0 == 0xFF && b1 == 0xFE) return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
            if (b0 == 0xFE && b1 == 0xFF) return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }
        if (bytes.size >= 3 &&
            (bytes[0].toInt() and 0xFF) == 0xEF &&
            (bytes[1].toInt() and 0xFF) == 0xBB &&
            (bytes[2].toInt() and 0xFF) == 0xBF
        ) {
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        return String(bytes, Charsets.UTF_8)
    }

    fun parse(content: String, sourceName: String): List<ChatMessage> {
        val messages = ArrayList<ChatMessage>()
        var current: ChatMessage? = null

        for (rawLine in content.lines()) {
            val line = rawLine.trimEnd('\r', '\n')
            val m = androidPattern.find(line) ?: iosPattern.find(line)

            if (m != null) {
                current?.let { messages.add(finish(it)) }
                val (date, time, sender, text) = m.destructured
                current = ChatMessage(date, time, sender, text, "", sourceName)
            } else if (current != null) {
                current.text += "\n" + line
            }
        }
        current?.let { messages.add(finish(it)) }
        return messages
    }

    // مبلغ بعد از اتصال خطوط چندخطی محاسبه می‌شود
    private fun finish(m: ChatMessage): ChatMessage =
        m.copy(amount = extractAmount(m.text))
}
