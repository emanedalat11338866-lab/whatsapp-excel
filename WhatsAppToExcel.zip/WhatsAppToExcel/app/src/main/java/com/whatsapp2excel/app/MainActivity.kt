package com.whatsapp2excel.app

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val REQ_PICK = 1
        private const val REQ_SAVE = 2
        private const val SHEET_NAME = "گزارش کل واتساپ"
        private const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var statusText: TextView
    private lateinit var pickButton: Button
    private lateinit var progress: ProgressBar

    private var messages: List<ChatMessage> = emptyList()
    private var fileCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(24)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "تبدیل چت واتساپ به اکسل"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }

        val hint = TextView(this).apply {
            text = "در واتساپ: گفتگو ← سه‌نقطه ← بیشتر ← خروجی گرفتن از چت ← بدون رسانه.\n" +
                "سپس فایل‌های txt را اینجا انتخاب کنید (چند فایل همزمان هم مجاز است)."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(24))
        }

        pickButton = Button(this).apply {
            text = "انتخاب فایل‌های واتساپ"
            textSize = 17f
            setOnClickListener { pickFiles() }
        }

        progress = ProgressBar(this).apply { visibility = View.GONE }

        statusText = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }

        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(title, LinearLayout.LayoutParams(match, wrap))
        root.addView(hint, LinearLayout.LayoutParams(match, wrap))
        root.addView(pickButton, LinearLayout.LayoutParams(match, wrap))
        root.addView(progress, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(16) })
        root.addView(statusText, LinearLayout.LayoutParams(match, wrap))

        setContentView(root)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun setBusy(busy: Boolean, message: String) {
        pickButton.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        statusText.text = message
    }

    // ---------- انتخاب فایل ----------

    private fun pickFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return

        when (requestCode) {
            REQ_PICK -> {
                val uris = ArrayList<Uri>()
                val clip = data.clipData
                if (clip != null) {
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                } else {
                    data.data?.let { uris.add(it) }
                }
                if (uris.isNotEmpty()) processFiles(uris)
            }
            REQ_SAVE -> data.data?.let { saveExcel(it) }
        }
    }

    // ---------- خواندن و تحلیل ----------

    private fun processFiles(uris: List<Uri>) {
        setBusy(true, "در حال خواندن فایل‌ها...")
        executor.execute {
            val all = ArrayList<ChatMessage>()
            var error: String? = null
            try {
                for (uri in uris) {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: continue
                    val text = WhatsAppParser.decode(bytes)
                    all.addAll(WhatsAppParser.parse(text, displayName(uri)))
                }
            } catch (e: Exception) {
                error = e.message ?: e.javaClass.simpleName
            }

            ui.post {
                when {
                    error != null -> setBusy(false, "خطا در خواندن فایل: $error")
                    all.isEmpty() -> setBusy(false, "هیچ پیامی شناسایی نشد.")
                    else -> {
                        messages = all
                        fileCount = uris.size
                        setBusy(false, "${all.size} پیام شناسایی شد. محل ذخیرهٔ فایل اکسل را انتخاب کنید...")
                        askSaveLocation()
                    }
                }
            }
        }
    }

    private fun displayName(uri: Uri): String {
        val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }
        return name ?: uri.lastPathSegment ?: "chat.txt"
    }

    // ---------- ذخیرهٔ اکسل ----------

    private fun askSaveLocation() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = XLSX_MIME
            putExtra(Intent.EXTRA_TITLE, "WhatsApp_All_Messages.xlsx")
        }
        startActivityForResult(intent, REQ_SAVE)
    }

    private fun saveExcel(target: Uri) {
        val snapshot = messages
        val files = fileCount
        setBusy(true, "در حال ساخت فایل اکسل...")

        executor.execute {
            var error: String? = null
            try {
                val headers = listOf("ردیف", "تاریخ", "ساعت", "فرستنده", "متن پیام", "مبلغ احتمالی", "فایل منبع")
                val widths = listOf(10.0, 18.0, 15.0, 25.0, 65.0, 25.0, 35.0)

                val rows = snapshot.asSequence().mapIndexed { i, m ->
                    listOf<Any>(i + 1, m.date, m.time, m.sender, m.text, m.amount, m.source)
                }

                contentResolver.openOutputStream(target, "wt")?.use { out ->
                    XlsxWriter.write(out, SHEET_NAME, headers, rows, snapshot.size, widths)
                } ?: throw IllegalStateException("امکان نوشتن در مقصد وجود ندارد")
            } catch (e: Exception) {
                error = e.message ?: e.javaClass.simpleName
            }

            ui.post {
                if (error != null) {
                    setBusy(false, "خطا در ساخت فایل: $error")
                } else {
                    setBusy(
                        false,
                        "فایل اکسل با موفقیت ساخته شد ✅\n\n" +
                            "تعداد پیام‌های استخراج‌شده: ${snapshot.size}\n" +
                            "تعداد فایل‌های پردازش‌شده: $files"
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }
}
