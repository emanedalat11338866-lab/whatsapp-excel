plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.whatsapp2excel.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.whatsapp2excel.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

// عمداً هیچ کتابخانه خارجی استفاده نشده است؛ ساخت اکسل با کد خودِ پروژه انجام می‌شود.
